import "./App.css";

import FetchDemo from "./components/FetchDemo";
import Weath from "./components/Weath";
import Weather from "./components/Weather";
import Weathers from "./components/Weathers";

function App() {
  return (
    <>
      {/* <FetchDemo /> */}
      {/* <Weather /> */}

      {/* <Weathers /> */}

      <Weath />
    </>
  );
}

export default App;
