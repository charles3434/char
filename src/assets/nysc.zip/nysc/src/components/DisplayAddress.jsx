import { useState } from "react";

function DisplayAddress() {
  // const [showAddress, setShowAddress] = useState(false);

  //   const handleShow = () => {
  //     setShowAddress(true); // setShowAddress(false) => setShowAddress(true)
  //   };

  //   const handleHide = () => {
  //     setShowAddress(false);
  //   };

  // const handleMultiple = () => {
  //   setShowAddress(!showAddress);
  // };
  return (
    <div>
      {/* <button onClick={handleShow}>show address</button>

      <button onClick={handleHide}>Hide address</button> */}

      {/* <button onClick={handleShow} className={"hide, show"}>  */}

      {/* <button onClick={handleMultiple}>{showAddress ? "Hide" : "Show"}</button> */}

      {/* <h2>User address is Lagos island</h2>
      <h2>User has no address</h2> */}

      {/* {showAddress ? (
        <h2>User address is Lagos island</h2>
      ) : (
        <h2>User has no address</h2>
      )} */}
    </div>
  );
}

export default DisplayAddress;
