// import React, { useState } from "react";

// function FetchDemo() {
//   const [users, setUsers] = useState([]);

//   const handleFetch = () => {
//     fetch("https://jsonplaceholder.typicode.com/users")
//       .then((response) => response.json())
//       .then((user) => {
//         // console.log(user);
//         setUsers(user);
//       });
//   };

//   //   const handleFecth8 = () => {
//   //     fetch("https://jsonplaceholder.typicode.com/users/8")
//   //       .then((response) => response.json())
//   //       .then((user) => {
//   //         console.log(user);
//   //         setUsers(user);
//   //       });
//   //   };

//   return (
//     <section>
//       <p>Fetch example</p>

//       <button onClick={handleFetch}>fetch users</button>

//       {/* <button onClick={handleFecth8}>fetch user 8</button> */}
//       {/*
//       <p>{users}</p> */}

//       <ol>
//         {users.map((user) => (
//           <li key={user.id}>
//             {/* <span>{user.id}</span> */}

//             <b>{user.name}</b>

//             <a href={user.website}>{user.website}</a>
//           </li>
//         ))}
//       </ol>
//     </section>
//   );
// }

// export default FetchDemo;

import React from "react";

function FetchDemo() {
  const handleFetch = () => {
    fetch("https://jsonplaceholder.typicode.com/posts").then((res) =>
      res.json().then((posts) => console.log(posts))
    );
  };

  return (
    <>
      <p>Fetch Demo</p>

      <button onClick={handleFetch}>Fetch Post</button>
    </>
  );
}

export default FetchDemo;
