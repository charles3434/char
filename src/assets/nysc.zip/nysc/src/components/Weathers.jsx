import React from "react";

function Weathers() {
  return <div>Weathers</div>;
}

export default Weathers;
