import React from "react";
import Button from "./Button";

function Footer() {
  return (
    <footer className="foot">
      foot
      <Button text={"Join us"} style={"foot2"} />
    </footer>
  );
}

export default Footer;
