import React from "react";
import Button from "./Button";

function HeroSection() {
  return (
    <>
      <div>HeroSection</div>
      {/* <Button text={"Let's talk"} style={"hero-btn"} /> */}

      <button className="hero-btn">Let's talk</button>
    </>
  );
}

export default HeroSection;
