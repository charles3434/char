import React from "react";

function Greeting({ isLoggedIn }) {
  // if else way

  //   if (isLoggedIn) {
  //     return <h1>User is logged in</h1>;
  //   } else {
  //     return <h1>User is logged out: please log in</h1>;
  //   }

  // Ternary operator -> {condition ? code to execute if condition is true : fallback code to execute if condition is false}
  //   return (
  //     <div>
  //       {isLoggedIn ? (
  //         <div>
  //           <h1>User is logged in</h1>
  //           <h3>Welcome mr jagaban </h3>
  //         </div>
  //       ) : (
  //         <div>
  //           <h1>User is logged out: please log in</h1>
  //           <a href="">Click to sign in</a>
  //         </div>
  //       )}
  //     </div>
  //   );

  // && for simple conditions
  return (
    <div>
      {isLoggedIn && (
        <div>
          <h1>User is logged in</h1>
          <h3>Welcome mr jagaban </h3>
        </div>
      )}
    </div>
  );
}

export default Greeting;
