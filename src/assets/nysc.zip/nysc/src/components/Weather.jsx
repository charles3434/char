import React, { useState } from "react";
import "../styles/weather.css";

function Weather() {
  const [city, setCity] = useState("");
  const [weather, setWeather] = useState(null);

  //   const steve = {
  //     age: 23,
  //     address: {
  //       street: "lagos",
  //       state: "Ikeja",
  //     },
  //   };
  //   const weathers = {
  //     location: {
  //       name: "Osun",
  //       country: "UK",
  //       region: "Africa",
  //     },
  //     current: {
  //       temp_c: 28.4,
  //       temp_f: 83.1,
  //       condition: {
  //         code: 1063,
  //         icon: "//cdn.weatherapi.com/weather/64x64/night/176.png",
  //         text: "Patchy rain nearby",
  //       },
  //     },
  //   };

  //   const fetchWeather = async () => {
  //     try {
  //       const res = await fetch(
  //         `https://api.weatherapi.com/v1/current.json?key=fd732575cfdf48b5902103226252706&q=${city}`
  //       );
  //       const data = await res.json();
  //       setWeather(data);
  //       //   console.log(data);
  //       console.log(weather);
  //     } catch (error) {
  //       console.log(error);
  //     }
  //   };

  const fetchWeather = async () => {
    try {
      const res = await fetch(
        `https://api.weatherapi.com/v1/current.json?key=fd732575cfdf48b5902103226252706&q=${city}`
      );
      const weatherData = await res.json();
      // console.log(weatherData);
      setWeather(weatherData);
      console.log(weather);
      //console.log(weathers);
    } catch (err) {
      console.log(err);
    }
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    //alert("testing");
    fetchWeather();
    // alert("testing");
  };
  return (
    <div className="app">
      <h1>Weather App </h1>

      <form className="search-form" onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Enter city"
          value={city}
          onChange={(e) => setCity(e.target.value)}
        />

        <button type="submit">Get Weather</button>
      </form>

      {/* <p>Below is the weather of {city}</p> */}

      {weather && (
        <div className="weather-card">
          <h2>
            {weather.location.name}, {weather.location.tz_id}
          </h2>

          <div className="weather-info">
            <img src={weather.current.condition.icon} alt="weather icon" />
            <p>{weather.current.condition.text}</p>

            <p>
              Temp: {weather.current.temp_c}
              <sup>o</sup>c
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

export default Weather;

// https://api.weatherapi.com/v1/current.json?key=${import.meta.env.VITE_WEATHER_API_KEY}&q=${city}
//   {
//     location: {
//         name: 'london'
//     }
//     condtion: {
//         temp: '40',
//         text: 'sunny'
//     }
//   }
