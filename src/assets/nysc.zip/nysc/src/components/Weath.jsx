import { useState } from "react";
import "../styles/weather.css";

function Weath() {
  const [city, setCity] = useState("");
  const [weather, setWeather] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    // alert("testiing");

    try {
      const response = await fetch(
        `https://api.weatherapi.com/v1/current.json?key=fd732575cfdf48b5902103226252706&q=${city}`
      );
      const data = await response.json();
      //console.log(data);
      // console.log(data.location.country);
      // console.log(data.location.region);
      // console.log(data.location.name);
      // console.log(data.current.temp_c);
      setWeather(data);
      console.log(weather);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div className="app">
      <h1>Weather App </h1>

      <form className="search-form" onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Enter city"
          value={city}
          onChange={(e) => setCity(e.target.value)}
        />

        <button type="submit">Get Weather</button>
      </form>

      {weather && (
        // <div>
        //   <p>{weather.location.name}</p>
        //   <img
        //     src={weather.current.condition.icon}
        //     alt={weather.current.condition.text}
        //   />
        //   <span>{weather.current.condition.text}</span>
        //   <span>
        //     {weather.current.temp_c} <sup>°C</sup>
        //   </span>
        // </div>
        <div className="weather-card">
          <h2>
            {weather.location.name}, {weather.location.tz_id}
          </h2>

          <div className="weather-info">
            <img src={weather.current.condition.icon} alt="weather icon" />
            <p>{weather.current.condition.text}</p>

            <p>
              Temp: {weather.current.temp_c}
              <sup>o</sup>c
            </p>
          </div>
        </div>
      )}
      {/* <p>Below is the weather of {city}</p> */}
    </div>
  );
}

export default Weath;
