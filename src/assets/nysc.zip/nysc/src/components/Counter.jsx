import React from "react";
import { useState } from "react";

function Counter() {
  // const [count, setCount] = useState(0);
  // const [name, setName] = useState("");

  // const handleAdd = () => {
  //   setCount(count + 5);
  // };

  // const handleName = (e) => {
  //   setName(e.target.value);
  // };

  // const [presentState, setPresentState] = useState(initialValue)

  // const handleTest = () => {
  //   alert("Testing subtract button if it works");
  // };

  const handleSubtract = () => {
    alert("Driving");
    console.log("Mr chisom is driving");
  };

  return (
    <div>
      <div>
        {/* <p>{count}</p> */}
        {/* <button onClick={handleAdd}>Add</button>
        <button onClick={() => setCount(count - 20)}>Sub</button> */}

        {/* Don't do this */}
        <button onClick={alert("Testing")}>Sub</button>

        {/* rather do this */}
        <button onClick={handleSubtract}>Subtract</button>
        {/* <input
          type="text"
          value={name}
          // onChange={(e) => setName(e.target.value)}
          onChange={handleName}
        /> */}
        {/* <p>the user name is : {name} </p> */}
      </div>
    </div>
  );
}

export default Counter;
