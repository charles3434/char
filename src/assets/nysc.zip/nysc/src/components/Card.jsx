import React from "react";

function Card({ name, role, jobDesc }) {
  return (
    <div>
      <div className="card">
        <h3>{name} </h3>
        <span>{role}</span>
        <p>{jobDesc}</p>
      </div>
    </div>
  );
}

export default Card;
