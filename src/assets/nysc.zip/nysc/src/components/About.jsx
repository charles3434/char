import React from "react";
import Button from "./Button";

function About() {
  return (
    <>
      <div>About</div>
      <Button text={"ReadMore"} style={"Chisom"} />
    </>
  );
}

export default About;
